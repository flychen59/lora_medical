from papermage.parsers.pdfplumber_parser import PDFPlumberParser

__all__ = [
    'PDFPlumberParser'
]