from .magelib import *
from .utils import get_version, group_by

__version__ = get_version()
